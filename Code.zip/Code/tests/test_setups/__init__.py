# Dummy to allow mock classes in the test files to have a version number for
# their parent module
__version__ = '0.1'
