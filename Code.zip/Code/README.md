[![License](https://img.shields.io/badge/License-BSD%203--Clause-blue.svg)](https://opensource.org/licenses/BSD-3-Clause)

A python interface for [OpenML](http://openml.org). You can find the documentation on the [openml-python website](https://openml.github.io/openml-python).

Please commit to the right branches following the gitflow pattern:
http://nvie.com/posts/a-successful-git-branching-model/

Master branch:

[![Build Status](https://travis-ci.com/adriansmares/openml-deeplearning.svg?token=Zacky3eEi6cg2MndspRi&branch=master)](https://travis-ci.com/adriansmares/openml-deeplearning)
