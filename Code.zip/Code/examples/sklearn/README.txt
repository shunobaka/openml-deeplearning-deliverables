scikit-learn Examples
===================

OpenML experiment examples using a sklearn classifier/pipeline.
