MXNet Examples
===================

OpenML experiment examples using MXNet hybrid sequential networks.
