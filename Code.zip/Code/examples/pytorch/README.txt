PyTorch Examples
===================

OpenML experiment examples using PyTorch sequential networks.
