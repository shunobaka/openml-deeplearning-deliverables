Keras Examples
===================

OpenML experiment examples using Keras sequential and functional networks.
