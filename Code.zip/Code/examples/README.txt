Introductory Examples
=====================

General examples for OpenML usage.
